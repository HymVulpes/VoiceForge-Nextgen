# RMVPE

This repo is the Pytorch implementation of ["RMVPE: A Robust Model for Vocal Pitch Estimation in Polyphonic Music"](https://arxiv.org/abs/2306.15412v2). 
